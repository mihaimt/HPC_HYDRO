#ifndef SLOPE_H_INCLUDED
#define SLOPE_H_INCLUDED

#include "utils.h"

void slope ( double *RESTRICT q, double *RESTRICT dq, const long narray,
             const long Hnvar, const long Hnxyt, const double slope_type );

#endif // SLOPE_H_INCLUDED
